import numpy as np
import pandas as pd
from scipy.optimize import curve_fit
import matplotlib.pyplot as plt

# --------------------------------------------------
# 1. Read data
# --------------------------------------------------
data = pd.read_csv("results.csv")
V = data["Volume"].values
E = data["Energy"].values

# Sort by volume (important for stability)
idx = np.argsort(V)
V = V[idx]
E = E[idx]

# --------------------------------------------------
# 2. Parabolic fit  E = aV^2 + bV + c  (initial guess)
# --------------------------------------------------
a, b, c = np.polyfit(V, E, 2)

V0_guess = -b / (2*a)
E0_guess = a*V0_guess**2 + b*V0_guess + c

# Bulk modulus initial guess from parabola curvature
# B0 ≈ 2aV0  (atomic units → convert later)
B0_guess = 2 * a * V0_guess

print("Initial guesses from parabola:")
print(f"V0 ≈ {V0_guess:.6f}")
print(f"E0 ≈ {E0_guess:.6f}")
print(f"B0 ≈ {B0_guess:.6f}")
print()

# --------------------------------------------------
# 3. Birch–Murnaghan EOS (3rd order)
# --------------------------------------------------
def birch_murnaghan(V, E0, V0, B0, Bp):
    eta = (V0 / V)**(2/3) - 1
    return E0 + (9*V0*B0/16) * (
        (eta**3)*Bp + (eta**2)*(6 - 4*(V0/V)**(2/3))
    )

# Initial parameters
p0 = [E0_guess, V0_guess, B0_guess, 4.0]

params, _ = curve_fit(birch_murnaghan, V, E, p0=p0)

E0, V0, B0, Bp = params

# --------------------------------------------------
# 4. Convert bulk modulus to GPa
# --------------------------------------------------
# 1 Hartree/Bohr^3 = 29421.02648438959 GPa
B0_GPa = B0 * 29421.02648438959
# Conversion factors
BOHR_TO_ANGSTROM = 0.52917721067
HARTREE_TO_EV = 27.2114

# Convert units
V0_ang = V0 * BOHR_TO_ANGSTROM**3  # Volume in Å^3
E0_ev = E0 * HARTREE_TO_EV         # Energy in eV
a0_ang = V0_ang**(1/3)             # Lattice constant (cubic)

# Print results in desired units
print("Birch–Murnaghan EOS Fit Results (converted units)")
print("----------------------------------")
print(f"Equilibrium volume V0  = {V0_ang:.6f} Å^3")
print(f"Equilibrium lattice a0 = {a0_ang:.6f} Å (assuming cubic)")
print(f"Minimum energy E0      = {E0_ev:.6f} eV")
print(f"Bulk modulus B0        = {B0_GPa:.3f} GPa")
print(f"B0' (dB0/dP)           = {Bp:.4f}")

# --------------------------------------------------
# 5. Plot data and fit
# --------------------------------------------------
V_fit = np.linspace(min(V)*0.98, max(V)*1.02, 500)
E_fit = birch_murnaghan(V_fit, *params)

plt.figure(figsize=(6,5))
plt.plot(V, E, 'ro', label='Data')
plt.plot(V_fit, E_fit, 'b-', label='Birch–Murnaghan fit')
plt.xlabel("Volume (Bohr³)")
plt.ylabel("Energy (Hartree)")
plt.title("Birch–Murnaghan EOS Fit")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.savefig("BM_fit.png", dpi=300)
plt.show()
