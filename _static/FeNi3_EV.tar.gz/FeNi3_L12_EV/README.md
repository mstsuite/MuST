File                  Description                                          Usage
i_mst                 Main input file            
Evec_input.dat        Moment direction data                           5 files required for the calculations
Fe_mt_v               Fe pseudopotential
Ni_mt_v               Ni pseudopotential
position.dat          Structure file
volume.dat            fraction to scale lattice constant
job.sh                job submission script, change according
                      to your cluster. MPI task number should be
                      multiple of number of atoms

job-submit            Bash script to run jobs for different volumes     ./job-submit
extract.sh            Extract volume energy from converged runs         ./extract.sh
                      and store results in result.csv file
eos.py                Python script to compute equation of state        python eos.py
