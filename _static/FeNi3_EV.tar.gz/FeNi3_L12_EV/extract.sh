#!/usr/bin/env bash

set -e

echo "Volume,Energy,TimeSec" > results.csv

for dir in V*/; do
    echo "Checking $dir"

    # find files
    ofile=$(ls ${dir}/o_n0000000_* 2>/dev/null || true)
    kfile=$(ls ${dir}/k_n0000000_* 2>/dev/null || true)

    # skip if files missing
    [[ -z "$ofile" || -z "$kfile" ]] && { echo "Missing files in $dir"; continue; }

    ############################################
    # 1. Check convergence
    ############################################
    if ! grep -q "End of a successful run" "$ofile"; then
        echo "Not converged: $dir"
        continue
    fi

    ############################################
    # 2. Extract TIME (seconds)
    ############################################
    time=$(grep "Job total including IO" "$ofile" | awk '{print $NF}' | sed 's/Sec//')

    ############################################
    # 3. Extract VOLUME (convert D+ → E+)
    ############################################
    volume=$(grep "Unit Cell Volume" "$kfile" | awk '{print $NF}' | sed 's/D/E/')
    volume=$(awk "BEGIN{printf \"%.10f\", $volume}")

    ############################################
    # 4. Extract ENERGY OFFSET
    ############################################
    offset=$(grep "Energy Offset" "$kfile" | awk '{print $NF}')

    ############################################
    # 5. Extract LAST ENERGY (last row, 2nd column)
    ############################################
    last_energy=$(grep -E "^[[:space:]]*[0-9]" "$kfile" | tail -n 1 | awk '{print $2}')

    ############################################
    # 6. Final energy = last + offset
    ############################################
    final_energy=$(awk -v a="$last_energy" -v b="$offset" 'BEGIN{printf "%.10f", a+b}')

    ############################################
    # 7. Save to CSV
    ############################################
    echo "$volume,$final_energy,$time" >> results.csv

done

echo "----------------------------------"
echo "Results written to results.csv"
